package com.test.capstone.userdrivermanagertest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserDriverManagerTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserDriverManagerTestApplication.class, args);
	}

}
